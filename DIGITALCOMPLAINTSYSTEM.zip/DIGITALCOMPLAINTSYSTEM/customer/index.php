<?php
session_start(); if (!isset($_SESSION['customer_logged_in'])) { header('Location: login.php'); exit; }
$page = $_GET['page'] ?? 'home';
?>
<!DOCTYPE html>
<html><head><title>Customer Portal</title></head><body>
<div class='sidebar'>
<a href='index.php?page=home'>Home</a>
<a href='index.php?page=track_complaints'>Track Complaints</a>
<a href='index.php?page=settings'>Settings</a>
<a href='logout.php'>Logout</a>
</div>
<div class='content'>
<?php include "includes/{$page}.php"; ?>
</div></body></html>