<?php
// Optional logout or session cleanup
?>