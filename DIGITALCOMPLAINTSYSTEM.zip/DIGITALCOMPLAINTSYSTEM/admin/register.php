<?php
// Admin registration logic
?>