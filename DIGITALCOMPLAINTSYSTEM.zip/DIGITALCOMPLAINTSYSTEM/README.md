# Digital Complaint System

Instructions to run and structure explained.